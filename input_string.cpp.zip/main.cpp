/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<sstream>
#include<vector>
using namespace std;
int main()
{   
    string input;
    getline(cin,input);
    stringstream sso(input);
    int token;
    vector<int> arr;
    while(sso>>token)
    {
        arr.push_back(token);
    }
    for(int n:arr)
    {
        cout<<n<<" ";
    }
    cout<<endl;
    return 0;
}